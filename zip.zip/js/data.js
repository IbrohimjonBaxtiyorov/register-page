export let products = [];

export function changer(data) {
  products = data;
  return products
}
