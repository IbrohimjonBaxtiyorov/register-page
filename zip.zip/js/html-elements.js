const elForm = document.getElementById("form");
const elLoader=document.getElementById("loader");
const elList=document.getElementById("list");
const elLoguout=document.getElementById("log-out");
const eladdButton=document.getElementById("add-but");
const elAddForm=document.getElementById("add-form");
const elSubmit=document.getElementById("submit-add")
export{elForm ,elLoader,elList,elLoguout,eladdButton,elAddForm,elSubmit}